<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category  BSS
 * @package   Bss_OneStepCheckoutCustomize
 * @author    Extension Team
 * @copyright Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license   http://bsscommerce.com/Bss-Commerce-License.txt
 */

namespace Bss\OneStepCheckoutCustomize\Plugin\Customer\Model;

/**
 * Class Address
 *
 * @package Bss\OneStepCheckoutCustomize\Plugin\Customer
 */
class AccountManagement
{
    /**
     * Checkout Session
     *
     * @var checkoutSession
     */
    private $checkoutSession;

    /**
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * @param \Magento\Customer\Model\AccountManagement $subject
     * @param mixed $result
     * @return mixed
     */
    public function aroundIsEmailAvailable(
        \Magento\Customer\Model\AccountManagement $subject,
        \Closure $proceed,
        $customerEmail,
        $websiteId
    ) {
        $currentQuote = $this->checkoutSession->getQuote();
        $currentQuote->setCustomerEmail($customerEmail)->save();
        return $proceed($customerEmail, $websiteId);
    }
}
